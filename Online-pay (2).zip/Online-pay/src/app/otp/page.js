import OTP from "@/components/OTP";

export default function OTPPage() {
  return (
    <div className="px-2">
      <OTP />
    </div>
  );
}
