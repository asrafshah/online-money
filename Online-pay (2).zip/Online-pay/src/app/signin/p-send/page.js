import LoadingSpinner from "@/components/LoadinSpinner";
import NotFound from "@/components/NotFound";
import React from "react";

function page() {
  return (
    <div >
      {/* <NotFound /> */}
    </div>
  );
}

export default page;
